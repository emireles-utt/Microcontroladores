/*
 * keypad.h
 *
 *  Created on: Nov 10, 2024
 *      Author: Eduardo
 */

#ifndef INC_KEYPAD_H_
#define INC_KEYPAD_H_

#include "main.h"

char read_keypad(void);

#endif /* INC_KEYPAD_H_ */
